package com.example.mavenspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
