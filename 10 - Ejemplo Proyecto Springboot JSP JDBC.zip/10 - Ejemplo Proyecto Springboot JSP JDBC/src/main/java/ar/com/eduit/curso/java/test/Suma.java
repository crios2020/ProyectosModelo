package ar.com.eduit.curso.java.test;

public class Suma {
    public int sumar(int nro1, int nro2){
        return nro1+nro2;
    }
}
