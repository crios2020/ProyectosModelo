package hola;
public class Hola{
    public static void main(String[] args) {
        System.out.println("Hola Mundo Java SE!");
        //para ejecutar, desde consola: 
    }
}