package com.example.demothymeleaf.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
