package com.example.demoapirest.repositories;

public class AlumnoRepository {
    
}
