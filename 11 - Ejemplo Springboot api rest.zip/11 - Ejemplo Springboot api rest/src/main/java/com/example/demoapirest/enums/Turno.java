package com.example.demoapirest.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
