package com.example.demoapirest.controllers;

public class AlumnoController {
    
}
