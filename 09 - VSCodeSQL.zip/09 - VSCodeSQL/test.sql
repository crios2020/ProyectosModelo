show databases;
select curdate();

-- Instale este plugin
-- https://marketplace.visualstudio.com/items?itemName=cweijan.vscode-mysql-client2
-- Mirar captura de pantalla adjunta para crear conection.
-- ALT + CTRL + C para cambiar la conexión activa.
-- CTRL + Enter para ejecutar una sola sentencia.

