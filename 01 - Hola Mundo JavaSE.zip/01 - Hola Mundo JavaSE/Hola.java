public class Hola{
    public static void main(String[] args) {
        System.out.println("Hola Mundo Java SE!");
        //para ejecutar, desde consola: 
        //                  javac Hola.java     //Compila el archivo .class
        //                  java Hola           //Ejecuta el archivo .class
    }
}